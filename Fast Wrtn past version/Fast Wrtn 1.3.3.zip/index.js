

//real-time apply
var lastest = "";
setInterval(()=>{
    //character/u
    const targetDiv = document.getElementsByClassName("css-d7pngb").item(0);
    if (targetDiv != null) {
        if (targetDiv.childNodes.length < 5) {
            main();
        }
    }
    //character/rank
    const rankDiv = document.getElementsByClassName("css-1j1qj3l").item(0);
    if (rankDiv != null){
        if (rankDiv.childNodes.length == 30){
            main();
        }
    }
    if (lastest != document.URL){
        if (document.URL == "https://wrtn.ai/character/my"){
            main();
        }
    }
    lastest = document.URL;
},1000)

function main(){
    function getCookie(name) {
      let matches = document.cookie.match(new RegExp(
        "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
      ));
      return matches ? decodeURIComponent(matches[1]) : undefined;
    }

    //character/u
    if (document.URL.split("/")[4] == "u"){
        const targetDiv = document.getElementsByClassName("css-d7pngb").item(0);
        const NS = document.getElementsByClassName("css-13yljkq").item(0);
        const MNS = document.getElementsByClassName("css-945n6l").item(0);
        const NBS = NS.cloneNode(true);
        const NBS_E = NS.cloneNode(true);
        const Cm_E = NBS_E.childNodes.item(0).childNodes.item(0);
        const Cm = NBS.childNodes.item(0).childNodes.item(0);
        const bar = document.getElementsByClassName("css-1diwz7b").item(0);
        const bar_c = bar.childNodes[1].childNodes[0].childNodes[1];
        const persona = bar.childNodes[1].childNodes[0].childNodes[1].childNodes.item(0).cloneNode(true);
        var l = []
        const persona_p = persona.childNodes.item(1);
        persona_p.textContent = "[페르소나]";
        const persona_svg = persona.childNodes.item(0);
        const persona_path = persona_svg.childNodes.item(0);
        var personal_modal = document.createElement("div");
        personal_modal.setAttribute("id","web-modal");
        document.body.appendChild(personal_modal);
        for (let i = 0; i < 4; i++) {
            persona_svg.childNodes[1].remove();
        }

        persona_path.setAttribute("d","M 12 2 C 7 2 4 4 4 7 V 11 C 4 16 8 20 12 20 C 16 20 20 16 20 11 V 7 C 20 4 17 2 12 2 Z Z Z M 9 14 C 9 13.5 10.5 13 12 13 C 13.5 13 15 13.5 15 14 C 15 14.5 14 15 12 15 C 10 15 9 14.5 9 14 Z M 6 9 L 8 8 C 8 8 9 8 10 9 C 9.3333 9.3333 9 10 8 10 L 8 10 C 7 10 6 10 6 9 C 6 9 6 9 6 9 C 6 9 7 8 8 8 M 14 9 C 15 8 16 8 16 8 C 17 8 18 9 18 9 C 18 10 17 10 16 10 C 15 10 14.6667 9.3333 14 9")
        persona.addEventListener('click',persona_change);
        bar_c.appendChild(persona);

        Cm.setAttribute("d","M 12 12 L 12 7 L 14 7 L 14 12 L 19 12 L 19 14 L 14 14 L 14 19 L 12 19 L 12 14 L 7 14 L 7 12 L 12 12");
        targetDiv.appendChild(NBS);
        NBS.addEventListener('click',clicked);

        Cm_E.setAttribute("d","M 12 12 L 7 12 L 7 14 L 19 14 L 19 12 L 12 12");
        targetDiv.appendChild(NBS_E);
        NBS_E.addEventListener('click',E_clicked);

        targetDiv.appendChild(NS);

        function clicked() {
            if (l.length == 9){
                return alert("9개가 최대 입니다.");
            }
            const vsm = document.getElementsByTagName("textarea").item(0);
            if (vsm.value == ''){
                return alert("내용 입력후 추가해주세요");
            }
            const vsmc = document.createElement("div");
            vsmc.setAttribute("display","flex");
            vsmc.setAttribute("class","css-13yljkq");
            vsmc.setAttribute("id",`${l.length}`);
            vsmc.append(`${l.length + 1}`);
            l[l.length] = [l.length,vsm.value]
            function v_clicked() {
                const vsm2 = document.getElementsByTagName("textarea").item(0);
                vsm2.value = l[vsmc.id][1];
            }
            vsmc.addEventListener("click",v_clicked);
            targetDiv.appendChild(vsmc);
            targetDiv.appendChild(NBS_E);
            targetDiv.appendChild(NS);
        }

        function E_clicked() {
            const a = document.getElementById(`${l.length-1}`);
            a.remove();
            l.pop();
        }


        window.addEventListener("keydown", keysPressed, false);
        window.addEventListener("keyup", keysReleased, false);

        var keys = [];

        function keysPressed(e) {
            keys[e.keyCode] = true;

            for (let i = 0; i < 58; i++) {
                 if (keys[17] && keys[49 + i] && l.length > i) {
                    const vsm = document.getElementsByTagName("textarea").item(0);
                    vsm.value = l[i][1];
                    e.preventDefault();	 // prevent default browser behavior
                }
            }
        }
        function keysReleased(e) {
            keys[e.keyCode] = false;
        }
        function persona_change(){
            fetch('https://api.wrtn.ai/be/user',{
              method: "GET",
              headers: {
                "Authorization": `Bearer ${getCookie("access_token")}`,
              }}).then(res => res.json()).then(data => {
                  fetch(`https://api.wrtn.ai/be/character-profiles/${data.data.wrtnUid}`,{
                      method: "GET",
                      headers: {
                        "Authorization": `Bearer ${getCookie("access_token")}`,
                      }
                }).then(res=>res.json()).then(data=>{
                    const pid = data.data._id;
                    fetch(`https://api.wrtn.ai/be/character-profiles/${data.data._id}/character-chat-profiles`,{
                      method: "GET",
                      headers: {
                        "Authorization": `Bearer ${getCookie("access_token")}`,
                      }
                    }).then(res=>res.json()).then(data=>{
                        if (bar_c.childNodes.length > 1){
                            for (let i = bar_c.childNodes.length - 1; i > 1 ; i--) {
                                bar_c.childNodes[2].remove();
                            }
                        }
                        c = 0;
                        for (const datum of data.data.characterChatProfiles) {
                            const personaL = persona.cloneNode(true);
                            const for_personaL = document.createElement("div");
                            personaL.insertBefore(for_personaL,personaL.childNodes[0]);
                            const personaL_p = personaL.childNodes.item(2);
                            if (datum.isRepresentative){
                             personaL_p.textContent = `${datum.name} <-`;
                            }
                            else {
                                personaL_p.textContent = datum.name;
                            }
                            personaL.setAttribute("id",`${c}`)
                            function personaL_change(){
                                var mpid = "";
                                m_i = 0;
                                for (m of data.data.characterChatProfiles) {
                                    if (`${m_i}` == personaL.id) {
                                        var mpid = m._id;
                                        var name = m.name;
                                        var information = m.information;
                                    }
                                    m_i++;
                                }
                                var personaL_change_modal = document.createElement("modal");
                                personaL_change_modal.innerHTML = "<div style=\"position: fixed; inset: 0px; z-index: -1; background-color: var(--color_bg_dimmed); cursor: default;\"><div style=\"align-items: flex-end; width: 100%; height: 100%; display: flex; -webkit-box-align: center; align-items: center; -webkit-box-pack: center; justify-content: center; position: relative;\"><div width=\"100%\" display=\"flex\" style=\"    width: 600px;\n" +
                                    "    max-width: calc(100% - 40px);\n" +
                                    "    background-color: var(--color_surface_elevated);\n" +
                                    "    max-height: 90dvh;\n" +
                                    "    overflow-y: auto;\n" +
                                    "    z-index: 15;\n" +
                                    "    border-width: initial;\n" +
                                    "    border-style: none;\n" +
                                    "    border-image: initial;\n" +
                                    "    border-color: var(--color_outline_secondary);\n" +
                                    "    border-radius: 12px;\n" +
                                    "    box-shadow: none;\n" +
                                    "    display: flex;\n" +
                                    "    flex-direction: column;\"><div display=\"flex\" style=\"    display: flex;\n" +
                                    "    flex-direction: column;\n" +
                                    "    -webkit-box-align: center;\n" +
                                    "    align-items: center;\n" +
                                    "    text-align: center;\"><div display=\"flex\" width=\"100%\" style=\"    display: flex;\n" +
                                    "    flex-direction: row;\n" +
                                    "    padding: 20px 24px;\n" +
                                    "    -webkit-box-align: center;\n" +
                                    "    align-items: center;\n" +
                                    "    -webkit-box-pack: justify;\n" +
                                    "    justify-content: space-between;\n" +
                                    "    width: 100%;\n" +
                                    "    border-bottom: 1px solid rgb(97, 96, 90);\"><p color=\"$color_text_primary\" style=\"    color: var(--color_text_primary);\n" +
                                    "    font-size: 20px;\n" +
                                    "    line-height: 100%;\n" +
                                    "    font-weight: 600;\">페르소나 수정</p><svg width=\"26\" height=\"26\" viewBox=\"0 0 24 25\" fill=\"currentColor\" xmlns=\"http://www.w3.org/2000/svg\" color=\"#a8a69dff\" cursor=\"pointer\" id=\"W_x\"><path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M12 11.0228L7.05026 6.07305L5.63604 7.48726L10.5858 12.437L5.63604 17.3868L7.05026 18.801L12 13.8512L16.9498 18.801L18.364 17.3868L13.4142 12.437L18.364 7.48726L16.9498 6.07305L12 11.0228Z\" fill=\"currentColor\"></path></svg></div><div display=\"flex\" width=\"100%\" style=\"    display: flex;\n" +
                                    "    flex-direction: column;\n" +
                                    "    padding: 20px;\n" +
                                    "    width: 100%;\n" +
                                    "    gap: 12px;\"><div display=\"flex\" style=\"    display: flex;\n" +
                                    "    flex-direction: column;\n" +
                                    "    gap: 8px;\"><p color=\"$color_text_primary\" style=\"    color: var(--color_text_primary);\n" +
                                    "    text-align: left;\n" +
                                    "    font-size: 16px;\n" +
                                    "    line-height: 100%;\n" +
                                    "    font-weight: 600;\">이름</p></div><textarea height=\"26px\" maxlength=\"12\" color=\"$color_text_primary\" placeholder=\"잊으면 안되는 중요한 내용, 추가하고 싶은 설정 등\" rows=\"5\" wrap=\"hard\" style=\"color: var(--color_text_primary);height: 26px; border-radius: 5px; border-width: 1px; border-style: solid; border-image: initial; border-color: var(--color_outline_secondary); background-color: var(--color_surface_ivory); padding: 11px 16px; min-height: 50px; max-height: 386px; font-size: 16px; line-height: 160%; font-weight: 500; resize: none; outline: none; caret-color: var(--color_text_brand);\" class=\"css-wmzh35\" id=\"W_name\"></textarea><div display=\"flex\" style=\"    display: flex;\n" +
                                    "    flex-direction: column;\n" +
                                    "    gap: 8px;\"><p color=\"$color_text_primary\" style=\"    color: var(--color_text_primary);\n" +
                                    "    text-align: left;\n" +
                                    "    font-size: 16px;\n" +
                                    "    line-height: 100%;\n" +
                                    "    font-weight: 600;\">정보</p></div><textarea height=\"26px\" maxlength=\"100\" placeholder=\"잊으면 안되는 중요한 내용, 추가하고 싶은 설정 등\" rows=\"5\" wrap=\"hard\" style=\"color: var(--color_text_primary);height: 26px; border-radius: 5px; border-width: 1px; border-style: solid; border-image: initial; border-color: var(--color_outline_secondary); background-color: var(--color_surface_ivory); padding: 11px 16px; min-height: 100px; max-height: 386px; font-size: 16px; line-height: 160%; font-weight: 500; resize: none; outline: none; caret-color: var(--color_text_brand);\" color=\"$color_text_primary\" class=\"css-wmzh35\" id=\"W_info\"></textarea></div><div display=\"flex\" width=\"100%\" style=\"    display: flex;\n" +
                                    "    flex-direction: row;\n" +
                                    "    width: 100%;\n" +
                                    "    -webkit-box-pack: end;\n" +
                                    "    justify-content: flex-end;\n" +
                                    "    gap: 8px;\n" +
                                    "    padding: 12px 20px 20px;\"><button display=\"flex\" width=\"100%\" height=\"40px\" color=\"$color_text_primary\" id=\"W_close\" style=\"    border-radius: 5px;\n" +
                                    "    -webkit-box-pack: center;\n" +
                                    "    justify-content: center;\n" +
                                    "    -webkit-box-align: center;\n" +
                                    "    align-items: center;\n" +
                                    "    display: flex;\n" +
                                    "    flex-direction: row;\n" +
                                    "    gap: 8px;\n" +
                                    "    width: 100%;\n" +
                                    "    border: 1px solid transparent;\n" +
                                    "    padding: 0px 20px;\n" +
                                    "    height: 40px;\n" +
                                    "    background-color: var(--color_surface_tertiary);\n" +
                                    "    color: var(--color_text_primary);\n" +
                                    "    font-size: 16px;\n" +
                                    "    line-height: 100%;\n" +
                                    "    font-weight: 600;\n" +
                                    "    cursor: pointer;\"><div display=\"flex\" style=\"    display: flex;\n" +
                                    "    flex-direction: row;\n" +
                                    "    gap: 8px;\n" +
                                    "    -webkit-box-align: center;\n" +
                                    "    align-items: center;\">닫기</div></button><button display=\"flex\" width=\"100%\" height=\"40px\" color=\"$color_text_ivory\" id=\"W_sumbit\" style=\"    border-radius: 5px;\n" +
                                    "    -webkit-box-pack: center;\n" +
                                    "    justify-content: center;\n" +
                                    "    -webkit-box-align: center;\n" +
                                    "    align-items: center;\n" +
                                    "    display: flex;\n" +
                                    "    flex-direction: row;\n" +
                                    "    gap: 8px;\n" +
                                    "    width: 100%;\n" +
                                    "    border: 1px solid transparent;\n" +
                                    "    padding: 0px 20px;\n" +
                                    "    height: 40px;\n" +
                                    "    background-color: var(--color_surface_primary);\n" +
                                    "    color: var(--color_text_ivory);\n" +
                                    "    font-size: 16px;\n" +
                                    "    line-height: 100%;\n" +
                                    "    font-weight: 600;\n" +
                                    "    cursor: pointer;\"><div display=\"flex\" style=\"    display: flex;\n" +
                                    "    flex-direction: row;\n" +
                                    "    gap: 8px;\n" +
                                    "    -webkit-box-align: center;\n" +
                                    "    align-items: center;\">등록</div></button></div></div></div></div></div>"
                                personal_modal.setAttribute("style","position: relative !important;\n" +
                                    "    z-index: 11 !important;")
                                personal_modal.appendChild(personaL_change_modal.firstChild);
                                var personal_modal_name = document.getElementById("W_name");
                                personal_modal_name.value = name;
                                var personal_modal_info = document.getElementById("W_info");
                                personal_modal_info.value = information;
                                var personal_modal_Sbtn = document.getElementById("W_sumbit");
                                var personal_modal_Cbtn = document.getElementById("W_close");
                                var personal_modal_x = document.getElementById("W_x");
                                personal_modal_Sbtn.addEventListener("click",()=>{
                                    fetch(`https://api.wrtn.ai/be/character-profiles/${pid}/character-chat-profiles/${mpid}`,{
                                     method: "PATCH",
                                      headers: {
                                        "Authorization": `Bearer ${getCookie("access_token")}`,
                                          "Content-Type": "application/json",
                                      },
                                      body: JSON.stringify({
                                        isRepresentative: true,
                                          name: personal_modal_name.value,
                                          information: personal_modal_info.value,
                                      })
                                    }).then(res=>res.json()).then(data=>{
                                        if (data.result == "SUCCESS"){
                                            alert("페르소나 등록 성공!");
                                            personal_modal.childNodes.item(0).remove();
                                            persona_change();
                                        }
                                        else{
                                            alert("페르소나 등록 실패!");
                                            personal_modal.childNodes.item(0).remove();
                                        }
                                    })
                                })
                                personal_modal_Cbtn.addEventListener("click",()=>{
                                    personal_modal.childNodes.item(0).remove();
                                })
                                personal_modal_x.addEventListener("click",()=>{
                                    personal_modal.childNodes.item(0).remove();
                                })
                            }
                            function personaL_change_double(){
                                alert("s");
                            }
                            personaL.addEventListener('click',personaL_change);
                            personaL.addEventListener('dbclick',personaL_change_double);
                            bar_c.appendChild(personaL);
                            c++;
                        }
                      })
                  })
            });
        }
    }
    // ranking
    if (document.URL.split("/")[4].split("?")[0] == "ranking"){
        if (document.URL.split("/")[4].split("?")[1].split("&")[1] == "period=weekly") {
            var rank = document.getElementsByClassName("css-1j1qj3l").item(0);
            fetch(`https://api.wrtn.ai/be/characters/ranking?limit=100&period=weekly`, {
                method: "GET",
                headers: {
                    "Authorization": `Bearer ${getCookie("access_token")}`,
                    "Content-Type": "application/json",
                },
            }).then(res => res.json()).then(data => {
                i = 0;
                for (const datum of data.data.characters) {
                    if (i > 29) {
                        var rank_struct = document.getElementsByClassName("css-134wxnj").item(0).cloneNode(true);
                        var img = rank_struct.childNodes[0].childNodes[0].childNodes[0].childNodes[0];
                        var rankV = rank_struct.childNodes[0].childNodes[0].childNodes[2].childNodes[0];
                        var rankName = rank_struct.childNodes[0].childNodes[1].childNodes[0];
                        var rankInfo = rank_struct.childNodes[0].childNodes[1].childNodes[1];
                        var rankCreater = rank_struct.childNodes[1].childNodes[1];
                        var rankCeCreater = rank_struct.childNodes[1].childNodes[2];
                        var rankIsAdult = rank_struct.childNodes[0].childNodes[0].childNodes[3].childNodes[0];
                        img.src = datum.profileImage.w600;
                        rankV.textContent = `${i + 1}`;
                        rankName.textContent = datum.name;
                        rankInfo.textContent = datum.description;
                        rankCreater.textContent = datum.creator.nickname;
                        if (datum.creator.isCertifiedCreator) {
                        } else {
                            rankCeCreater.remove();
                        }
                        if (datum.isAdult){}
                        else{
                            rankIsAdult.remove();
                        }
                        rank_struct.addEventListener('click', () => {
                            location.href = `https://wrtn.ai/character/u/${datum._id}`;
                        })
                        rank.appendChild(rank_struct);
                    }
                    i++;
                }
            })
        }
        if (document.URL.split("/")[4].split("?")[1].split("&")[1] == "period=monthly") {
            var rank = document.getElementsByClassName("css-1j1qj3l").item(0);
            fetch(`https://api.wrtn.ai/be/characters/ranking?limit=100&period=monthly`, {
                method: "GET",
                headers: {
                    "Authorization": `Bearer ${getCookie("access_token")}`,
                    "Content-Type": "application/json",
                },
            }).then(res => res.json()).then(data => {
                i = 0;
                for (const datum of data.data.characters) {
                    if (i > 29) {
                        var rank_struct = document.getElementsByClassName("css-134wxnj").item(0).cloneNode(true);
                        var img = rank_struct.childNodes[0].childNodes[0].childNodes[0].childNodes[0];
                        var rankV = rank_struct.childNodes[0].childNodes[0].childNodes[2].childNodes[0];
                        var rankName = rank_struct.childNodes[0].childNodes[1].childNodes[0];
                        var rankInfo = rank_struct.childNodes[0].childNodes[1].childNodes[1];
                        var rankCreater = rank_struct.childNodes[1].childNodes[1];
                        var rankCeCreater = rank_struct.childNodes[1].childNodes[2];
                        var rankIsAdult = rank_struct.childNodes[0].childNodes[0].childNodes[3].childNodes[0];
                        img.src = datum.profileImage.w600;
                        rankV.textContent = `${i + 1}`;
                        rankName.textContent = datum.name;
                        rankInfo.textContent = datum.description;
                        rankCreater.textContent = datum.creator.nickname;
                        if (datum.creator.isCertifiedCreator) {
                        } else {
                            rankCeCreater.remove();
                        }
                        if (datum.isAdult){}
                        else{
                            rankIsAdult.remove();
                        }
                        rank_struct.addEventListener('click', () => {
                            location.href = `https://wrtn.ai/character/u/${datum._id}`;
                        })
                        rank.appendChild(rank_struct);
                    }
                    i++;
                }
            })
        }
        if (document.URL.split("/")[4].split("?")[1].split("&")[1] == "period=daily") {
            var rank = document.getElementsByClassName("css-1j1qj3l").item(0);
            fetch(`https://api.wrtn.ai/be/characters/ranking?limit=100&period=daily`, {
                method: "GET",
                headers: {
                    "Authorization": `Bearer ${getCookie("access_token")}`,
                    "Content-Type": "application/json",
                },
            }).then(res => res.json()).then(data => {
                i = 0;
                for (const datum of data.data.characters) {
                    if (i > 29) {
                        var rank_struct = document.getElementsByClassName("css-134wxnj").item(0).cloneNode(true);
                        var img = rank_struct.childNodes[0].childNodes[0].childNodes[0].childNodes[0];
                        var rankV = rank_struct.childNodes[0].childNodes[0].childNodes[2].childNodes[0];
                        var rankName = rank_struct.childNodes[0].childNodes[1].childNodes[0];
                        var rankInfo = rank_struct.childNodes[0].childNodes[1].childNodes[1];
                        var rankCreater = rank_struct.childNodes[1].childNodes[1];
                        var rankCeCreater = rank_struct.childNodes[1].childNodes[2];
                        var rankIsAdult = rank_struct.childNodes[0].childNodes[0].childNodes[3].childNodes[0];
                        img.src = datum.profileImage.w600;
                        rankV.textContent = `${i + 1}`;
                        rankName.textContent = datum.name;
                        rankInfo.textContent = datum.description;
                        rankCreater.textContent = datum.creator.nickname;
                        if (datum.creator.isCertifiedCreator) {
                        } else {
                            rankCeCreater.remove();
                        }
                        if (datum.isAdult){}
                        else{
                            rankIsAdult.remove();
                        }
                        rank_struct.addEventListener('click', () => {
                            location.href = `https://wrtn.ai/character/u/${datum._id}`;
                        })
                        rank.appendChild(rank_struct);
                    }
                    i++;
                }
            })
        }
    }
    // 클립보드의 텍스트를 가져오기
    function getClipboardTextModern() {
        return navigator.clipboard.readText(); // 붙여넣기
    }

    // 텍스트를 클립보드에 복사하기
    function copyToClipboard(text) {
        navigator.clipboard.writeText(text) // 복사하기
            .then(() => {
                console.log('클립보드에 복사되었습니다.');
            })
            .catch(err => {
                console.error('클립보드 복사에 실패했습니다:', err);
            });
    }

    if (document.URL.split("/")[4] == "my"){
        opened = false;
        listend = false;
        now_clicked = 0;
        setInterval(()=>{
            const tdot = document.getElementsByClassName("css-1w2weol").item(0);
            const tsmc = document.getElementsByClassName("css-j7qwjs");
            if (tsmc != null){
                if (listend == false || tsmc.item(0).id == null){
                    i = 0;
                    for (const tsmcElement of tsmc) {
                        tsmcElement.setAttribute("id",`${i}`);
                        tsmcElement.addEventListener("click",()=>{
                            now_clicked = tsmcElement.id
                        })
                        i++;
                    }
                    listend = true;
                }
            }
            if (tdot != null && opened == false){
                const tdot_struct = tdot.childNodes.item(0).cloneNode(true);
                const tdot_struct_input = tdot.childNodes.item(0).cloneNode(true);
                tdot_struct.addEventListener("click",()=>{
                    fetch('https://api.wrtn.ai/be/characters/me?limit=10',{
                        method: "GET",
                        headers: {
                            "Authorization": `Bearer ${getCookie("access_token")}`,
                        },
                    }).then(res => res.json()).then(data => {
                        i=0;
                        for (const datum of data.data.characters) {
                            if (`${i}` == now_clicked){
                                fetch(`https://api.wrtn.ai/be/characters/me/${datum._id}`,{
                                    method: "GET",
                                    headers: {
                                        "Authorization": `Bearer ${getCookie("access_token")}`,
                                    },
                                }).then(res => res.json()).then(data => {
                                    copyToClipboard(JSON.stringify(data.data));
                                    alert('클립보드에 복사되었습니다!');
                                })
                            }
                            i++;
                        }
                    })
                })
                tdot_struct_input.addEventListener('click',()=>{
                    fetch('https://api.wrtn.ai/be/characters/me?limit=10',{
                        method: "GET",
                        headers: {
                            "Authorization": `Bearer ${getCookie("access_token")}`,
                        },
                    }).then(res => res.json()).then(data => {
                        i=0;
                        for (const datum of data.data.characters) {
                            if (`${i}` == now_clicked){
                                getClipboardTextModern().then(function (clipboardContent) {
                                    json_data = JSON.parse(clipboardContent);
                                    for (const a of json_data.startingSets) {
                                        delete a._id;
                                    }
                                    console.log(json_data.startingSets);
                                    fetch(`https://api.wrtn.ai/be/characters/${datum._id}`,{
                                        method: "PATCH",
                                        headers: {
                                            "Authorization": `Bearer ${getCookie("access_token")}`,
                                            "Content-Type": "application/json",
                                        },
                                        body: JSON.stringify({
                                            name: json_data.name,
                                            description: json_data.description,
                                            profileImageUrl: json_data.profileImage.origin,
                                            model: json_data.model,
                                            initialMessages: json_data.initialMessages,
                                            characterDetails: json_data.characterDetails,
                                            replySuggestions: json_data.replySuggestions,
                                            chatExamples: json_data.chatExamples,
                                            situationImages: json_data.situationImages,
                                            categoryIds: json_data.categories._id,
                                            tags: json_data.tags,
                                            visibility: json_data.visibility,
                                            promptTemplate: json_data.promptTemplate.template,
                                            isCommentBlocked: json_data.isCommentBlocked,
                                            defaultStartingSetName: json_data.defaultStartingSetName,
                                            startingSets: json_data.startingSets,
                                            keywordBook: json_data.keywordBook,
                                            customPrompt: json_data.customPrompt,
                                            defaultStartingSetSituationPrompt: json_data.defaultStartingSetSituationPrompt,
                                        })
                                    }).then(res=>res.json).then(data=>{
                                        alert("캐챗 변경 성공! (새로고침 후 적용됩니다.)");
                                    })
                                })
                            }
                            i++;
                        }
                    })
                })
                tdot_struct.childNodes.item(0).textContent = "copy to json";
                tdot_struct_input.childNodes.item(0).textContent = "paste to json";
                tdot.appendChild(tdot_struct);
                tdot.appendChild(tdot_struct_input);
                opened = true;
            }
            if (tdot == null){
                opened = false;
            }
        },100)
    }
}


