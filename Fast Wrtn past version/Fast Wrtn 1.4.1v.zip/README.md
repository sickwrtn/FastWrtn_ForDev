# FastWrtn
Fast Wrtn chrome extension code
